# Fable Wargame — 8 Pass Criteria
1. Every move states its expected observation.
2. Every move carries its most likely failure and counter-move.
3. Every fork has a trigger.
4. Every assumption recon could not settle is marked RECON NEEDED.
5. Abort conditions exist.
6. Verification is spelled out.
7. It has survived a red-team pass.
8. It is executable blind.
