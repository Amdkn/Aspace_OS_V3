# Fable Wargame Kit
A bounded simulation framework for testing autonomous agent execution and identifying unknowns. Contains 10 task briefs, 8 pass criteria, and an operational ledger.
